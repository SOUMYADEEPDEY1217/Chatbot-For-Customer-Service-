# Simple rule-based chatbot
def get_response(user_input):
    responses = {
        "hi": "Hello! How can I help you?",
        "bye": "Goodbye! Have a great day!",
        "help": "You can ask about our services, timings, or location.",
    }
    return responses.get(user_input.lower(), "I'm sorry, I don't understand that.")

if __name__ == "__main__":
    print("Welcome to Customer Service Chatbot!")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            break
        print("Bot:", get_response(user_input))
